// worker.js — Cloudflare Worker
//
// Holds the Anthropic API key server-side so the browser extension never
// contains it. Deploy this once; the extension calls it instead of
// api.anthropic.com directly.
//
// Setup:
//   1. npm install -g wrangler
//   2. wrangler login
//   3. wrangler secret put ANTHROPIC_API_KEY      (paste your key when prompted)
//   4. wrangler secret put EXTENSION_SHARED_SECRET (any random string you make up —
//      this is NOT your Anthropic key, it's just a shared password between
//      your extension and this worker so random people can't use your worker
//      as a free relay to your Anthropic account)
//   5. wrangler deploy
//   6. Copy the resulting *.workers.dev URL into AI_WORKER_URL in background.js,
//      and the same shared secret into WORKER_SHARED_SECRET in background.js.

const SYSTEM_PROMPT =
  "You review webpage text for an anti-scam browser extension. Look for " +
  "signs of scam/phishing e-commerce sites: urgency pressure, fake urgency " +
  "countdowns, implausible discounts, requests for unusual payment methods, " +
  "poor/garbled copy typical of cloned stores, fake trust badges, etc. Also " +
  "note if the site clearly looks like an established, identifiable " +
  "legitimate business or well-known payment processor (name it if so). " +
  "Separately, if the page contains or is near a payment/checkout form, " +
  "assess whether it specifically looks SAFE to enter real card details " +
  "into: is the merchant/business identifiable, does the checkout look " +
  "like a known/legitimate payment flow vs. an anonymous or fake store, " +
  "any red flags near the payment step itself. Respond with ONLY compact " +
  "JSON, no other text: " +
  '{"verdict":"scam"|"likely-legitimate"|"unclear","reason":"<one short sentence>",' +
  '"cardSafety":"safe"|"risky"|"unclear","cardReason":"<one short sentence>"}. ' +
  'Use "scam"/"risky" only for a clear, specific, nameable red flag. Use ' +
  '"likely-legitimate"/"safe" only if you can name the specific business/brand ' +
  'or a recognizable, legitimate payment flow. Default to "unclear" otherwise — ' +
  "false confidence in either direction is costly.";

// Very basic per-IP rate limit, in-memory (resets whenever the Worker
// instance recycles — not durable, but blunts casual abuse for free).
// For real public traffic, replace with Cloudflare Rate Limiting or a
// Durable Object / KV-backed counter.
const requestLog = new Map(); // ip -> [timestamps]
const RATE_LIMIT = 20; // requests
const RATE_WINDOW_MS = 60 * 1000; // per minute

function isRateLimited(ip) {
  const now = Date.now();
  const timestamps = (requestLog.get(ip) || []).filter((t) => now - t < RATE_WINDOW_MS);
  timestamps.push(now);
  requestLog.set(ip, timestamps);
  return timestamps.length > RATE_LIMIT;
}

export default {
  async fetch(request, env) {
    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    if (isRateLimited(ip)) {
      return new Response(JSON.stringify({ error: "rate_limited" }), {
        status: 429,
        headers: { "Content-Type": "application/json" }
      });
    }

    const providedSecret = request.headers.get("x-extension-secret");
    if (!env.EXTENSION_SHARED_SECRET || providedSecret !== env.EXTENSION_SHARED_SECRET) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json" }
      });
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ error: "invalid_json" }), { status: 400 });
    }

    const { url, pageText } = body;
    if (!url || typeof pageText !== "string") {
      return new Response(JSON.stringify({ error: "missing_fields" }), { status: 400 });
    }

    try {
      const anthropicResp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: "claude-sonnet-5",
          max_tokens: 200,
          system: SYSTEM_PROMPT,
          messages: [
            { role: "user", content: `URL: ${url}\n\nPage text:\n${pageText.slice(0, 4000)}` }
          ]
        })
      });

      if (!anthropicResp.ok) {
        return new Response(JSON.stringify({ error: "upstream_error" }), { status: 502 });
      }

      const data = await anthropicResp.json();
      const textBlock = (data.content || []).find((b) => b.type === "text");
      if (!textBlock) {
        return new Response(JSON.stringify({ error: "no_text_block" }), { status: 502 });
      }

      // Validate it's actually the JSON shape we expect before passing it on.
      const parsed = JSON.parse(textBlock.text.trim());
      return new Response(JSON.stringify(parsed), {
        headers: { "Content-Type": "application/json" }
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: "worker_exception" }), { status: 500 });
    }
  }
};
