const input = document.getElementById("apiKey");
const status = document.getElementById("status");

chrome.storage.local.get(["safeBrowsingApiKey"], ({ safeBrowsingApiKey }) => {
  if (safeBrowsingApiKey) input.value = safeBrowsingApiKey;
});

document.getElementById("save").addEventListener("click", () => {
  chrome.storage.local.set({ safeBrowsingApiKey: input.value.trim() }, () => {
    status.textContent = "Saved.";
    setTimeout(() => (status.textContent = ""), 1500);
  });
});
