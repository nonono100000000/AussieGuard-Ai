// content.js — runs on every page (and, per manifest, every frame on the page)

const isTopFrame = window.self === window.top;

// Lets any frame (including a payment iframe) receive the "lock card fields"
// instruction, since it may not be able to compute its own verdict — the
// top frame's URL is what actually got flagged.
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "ENABLE_CARD_LOCK") enableScamModeCardLock();
});

const SCAM_KEYWORDS = [
  "verify your account immediately",
  "confirm your password",
  "your account will be suspended",
  "pay now or your account closes",
  "unusual activity detected",
  "click here to avoid suspension",
  "urgent action required",
  "your account has been limited",
  "restore access now"
];

// Curated, deliberately small starter list — category keyword -> Australian brand suggestion.
// This only ever shows a dismissible suggestion; it never touches payment fields or forms.
const AU_ALTERNATIVES = [
  { match: /\bcoffee\b/i, label: "Coffee", brand: "Try an Aussie roaster, e.g. Genovese or Padre Coffee" },
  { match: /\bskincare|moisturi[sz]er|sunscreen\b/i, label: "Skincare", brand: "Consider Aussie-made, e.g. Frank Body or Go-To" },
  { match: /\bactivewear|gym\s?wear\b/i, label: "Activewear", brand: "Consider Aussie-made, e.g. 2XU or Lorna Jane" },
  { match: /\bwool|jumper|knitwear\b/i, label: "Wool/Knitwear", brand: "Consider Aussie wool brands, e.g. R.M.Williams" },
  { match: /\bhoney\b/i, label: "Honey", brand: "Consider Aussie honey, e.g. Capilano" }
];

function hasUrgentLanguage() {
  const text = document.body ? document.body.innerText.toLowerCase() : "";
  return SCAM_KEYWORDS.some((phrase) => text.includes(phrase));
}

function looksLikeShoppingPage() {
  const text = document.body ? document.body.innerText.toLowerCase() : "";
  return /\bcart\b|\bcheckout\b|\badd to cart\b|\bbuy now\b/.test(text);
}

// Cheap, top-frame-only pre-check: is there anything card-shaped on this
// page at all? (isLikelyCardField is defined further down; function
// declarations are hoisted, so this is safe to call here.)
function pageHasCardField() {
  return Array.from(document.querySelectorAll("input")).some(isLikelyCardField);
}

function requestVerdict() {
  if (!isTopFrame) return; // only the top page's URL/content should be analyzed
  chrome.runtime.sendMessage(
    {
      action: "ANALYZE_URL",
      payload: {
        url: location.href,
        hostname: location.hostname,
        hasUrgentLanguage: hasUrgentLanguage(),
        pageText: document.body ? document.body.innerText.slice(0, 4000) : "",
        hasCardField: pageHasCardField()
      }
    },
    (verdict) => {
      if (!verdict) return; // extension context may have been invalidated (e.g. on reload)
      showBadge(verdict);
      if (verdict.level === "scam") {
        enableScamModeCardLock(); // lock fields in this (top) frame
        // Ask the background worker to broadcast to every frame in this tab,
        // since card-number fields on real checkouts usually live in a
        // separate, cross-origin payment iframe (Braintree/Stripe/Adyen etc.)
        // that this top-frame script can't reach directly.
        chrome.runtime.sendMessage({ action: "REQUEST_CARD_LOCK_BROADCAST" });
      }
    }
  );
}

// --- Floating trust badge ---
let badgeEl = null;

function showBadge(verdict) {
  const colors = { trusted: "#10b981", unknown: "#f59e0b", scam: "#ef4444" };
  const labels = { trusted: "Trusted", unknown: "Unverified", scam: "Scam risk" };

  if (!badgeEl) {
    badgeEl = document.createElement("div");
    badgeEl.id = "aussieguard-badge";
    badgeEl.style.cssText = `
      position: fixed; top: 12px; right: 12px; z-index: 2147483647;
      font-family: -apple-system, sans-serif; font-size: 13px; font-weight: 600;
      color: #fff; padding: 8px 14px; border-radius: 999px; cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,0.25); transition: background 0.2s;
      user-select: none;
    `;
    document.documentElement.appendChild(badgeEl);

    let tooltip = null;
    badgeEl.addEventListener("click", () => {
      if (tooltip) { tooltip.remove(); tooltip = null; return; }
      tooltip = document.createElement("div");
      tooltip.style.cssText = `
        position: fixed; top: 48px; right: 12px; z-index: 2147483647;
        background: #111827; color: #e5e7eb; font-family: -apple-system, sans-serif;
        font-size: 12px; padding: 10px 12px; border-radius: 8px; max-width: 260px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.35);
      `;
      tooltip.textContent = badgeEl.dataset.reasons || "No details available.";
      document.documentElement.appendChild(tooltip);
    });
  }

  badgeEl.style.background = colors[verdict.level];
  badgeEl.textContent = labels[verdict.level];
  const reasonText = (verdict.reasons || []).join(" • ");
  badgeEl.dataset.reasons = verdict.suggestTrust
    ? `${reasonText} • 🤖 AI thinks this may be legitimate: ${verdict.suggestReason} (open the popup to mark it trusted)`
    : reasonText || "No details available.";
}

// --- Australian-alternative suggestion banner (shopping pages only) ---
function maybeShowAuSuggestion() {
  if (!looksLikeShoppingPage()) return;
  const pageText = document.body ? document.body.innerText : "";
  const hit = AU_ALTERNATIVES.find((entry) => entry.match.test(pageText));
  if (!hit) return;

  chrome.storage.local.get(["dismissedAuSuggestions"], ({ dismissedAuSuggestions }) => {
    const dismissed = dismissedAuSuggestions || [];
    if (dismissed.includes(hit.label)) return;

    const banner = document.createElement("div");
    banner.style.cssText = `
      position: fixed; bottom: 16px; right: 16px; z-index: 2147483647;
      background: #1f2937; color: #f3f4f6; font-family: -apple-system, sans-serif;
      font-size: 13px; padding: 12px 14px; border-radius: 10px; max-width: 280px;
      box-shadow: 0 4px 14px rgba(0,0,0,0.35); line-height: 1.4;
    `;
    banner.innerHTML = `
      🇦🇺 <strong>${hit.label} shopping?</strong><br>${hit.brand}
      <div style="margin-top:8px; display:flex; gap:8px;">
        <button id="ag-dismiss" style="flex:1; padding:5px 0; border:none; border-radius:6px; background:#374151; color:#fff; cursor:pointer;">Dismiss</button>
      </div>
    `;
    document.documentElement.appendChild(banner);
    banner.querySelector("#ag-dismiss").addEventListener("click", () => {
      banner.remove();
      chrome.storage.local.set({ dismissedAuSuggestions: [...dismissed, hit.label] });
    });
  });
}

// --- Card-field lock, activated only when a page is flagged "scam" ---
// Disables anything that looks like a card-number field so the user can't
// type or paste into it, and blocks form submission as a backstop.
let scamModeActive = false;
let scamWarningShown = false;

function isLikelyCardField(input) {
  const autocomplete = (input.getAttribute("autocomplete") || "").toLowerCase();
  if (autocomplete.includes("cc-number")) return true;

  const haystack = [
    input.name, input.id, input.placeholder, input.getAttribute("aria-label")
  ].filter(Boolean).join(" ").toLowerCase();
  if (/card.?(num|number)|cc.?num|credit.?card/.test(haystack)) return true;

  // Generic numeric field shaped like a 13–19 digit card number, e.g.
  // <input type="tel" maxlength="19"> with no other identifying info.
  const maxLength = parseInt(input.getAttribute("maxlength") || "0", 10);
  if ((input.type === "tel" || input.type === "text") && maxLength >= 13 && maxLength <= 19) {
    return true;
  }
  return false;
}

function showScamCardWarning() {
  if (scamWarningShown) return;
  scamWarningShown = true;
  const warning = document.createElement("div");
  warning.style.cssText = `
    position: fixed; top: 56px; right: 12px; z-index: 2147483647;
    background: #7f1d1d; color: #fff; font-family: -apple-system, sans-serif;
    font-size: 13px; padding: 12px 14px; border-radius: 10px; max-width: 280px;
    line-height: 1.4; box-shadow: 0 4px 14px rgba(0,0,0,0.4);
  `;
  warning.innerHTML = `🚨 <strong>Card entry blocked</strong><br>
    This site was flagged as a scam risk, so AussieGuard is blocking payment
    card fields on this page.`;
  document.documentElement.appendChild(warning);
  setTimeout(() => warning.remove(), 8000);
}

function lockCardField(input) {
  if (input.dataset.aussieguardLocked) return;
  input.dataset.aussieguardLocked = "true";
  input.setAttribute("readonly", "true");
  input.style.setProperty("border", "2px solid #ef4444", "important");
  input.style.setProperty("background", "#3f1d1d", "important");
  input.style.setProperty("cursor", "not-allowed", "important");
  input.title = "Blocked by AussieGuard: this site was flagged as a scam risk";

  const block = (e) => { e.preventDefault(); e.stopPropagation(); showScamCardWarning(); };
  input.addEventListener("keydown", block, true);
  input.addEventListener("paste", block, true);
  input.addEventListener("focus", () => { input.blur(); showScamCardWarning(); }, true);
}

function scanAndLockCardFields() {
  document.querySelectorAll("input").forEach((input) => {
    if (isLikelyCardField(input)) lockCardField(input);
  });
}

function blockScamFormSubmits(e) {
  const form = e.target;
  if (form.querySelector('[data-aussieguard-locked="true"]')) {
    e.preventDefault();
    e.stopPropagation();
    showScamCardWarning();
  }
}

function enableScamModeCardLock() {
  if (scamModeActive) return;
  scamModeActive = true;
  scanAndLockCardFields();
  document.addEventListener("submit", blockScamFormSubmits, true);

  // Many checkout forms render fields after the initial page load (SPA
  // checkouts, embedded payment iframes' host containers, etc.), so keep
  // watching for new inputs while scam mode is active.
  const observer = new MutationObserver(() => scanAndLockCardFields());
  observer.observe(document.documentElement, { childList: true, subtree: true });
}

requestVerdict();
if (isTopFrame) maybeShowAuSuggestion();

// --- Late card-field detection (any frame, including iframes) ---
// pageHasCardField() at the top only sees the top frame's own DOM. Real
// checkouts usually put the card field in a separate iframe that may not
// exist yet when the top frame's first check runs — this catches that.
let cardFieldReported = false;
function reportCardFieldIfPresent() {
  if (cardFieldReported) return;
  if (pageHasCardField()) {
    cardFieldReported = true;
    chrome.runtime.sendMessage({ action: "CARD_FIELD_PRESENT" });
  }
}
reportCardFieldIfPresent();
const cardFieldObserver = new MutationObserver(() => reportCardFieldIfPresent());
cardFieldObserver.observe(document.documentElement, { childList: true, subtree: true });

// Lets the top frame refresh its badge/tooltip after a late escalation
// (e.g. the payment iframe's card field only became known after the
// initial check, and the background worker upgraded the verdict to "scam").
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "VERDICT_UPDATE" && isTopFrame) showBadge(message.verdict);
});
