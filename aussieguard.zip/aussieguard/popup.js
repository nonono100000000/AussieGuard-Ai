const badgeEl = document.getElementById("badge");
const reasonsEl = document.getElementById("reasons");
const trustActionEl = document.getElementById("trustAction");
const colors = { trusted: "#10b981", unknown: "#f59e0b", scam: "#ef4444" };
const labels = { trusted: "✅ Trusted", unknown: "❓ Unverified", scam: "🚨 Scam risk" };

document.getElementById("optionsLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

function renderTrustAction(verdict, hostname) {
  trustActionEl.innerHTML = "";

  if (verdict.level === "trusted") {
    // Only offer "remove" for domains *you* added — not the built-in list.
    if (verdict.reasons.some((r) => r.startsWith("You've marked"))) {
      const btn = document.createElement("button");
      btn.className = "trust-btn remove";
      btn.textContent = "Remove from my trusted list";
      btn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "REMOVE_TRUSTED_DOMAIN", hostname }, () => {
          btn.textContent = "Removed — reload the page to apply";
          btn.disabled = true;
        });
      });
      trustActionEl.appendChild(btn);
    }
    return;
  }

  if (verdict.level === "scam") return; // never offer to trust a flagged site

  // level === "unknown": always allow a manual trust decision, and
  // highlight it if the AI specifically suggested this looks legitimate.
  if (verdict.suggestTrust && verdict.suggestReason) {
    const hint = document.createElement("div");
    hint.className = "ai-hint";
    hint.textContent = `🤖 AI: ${verdict.suggestReason}`;
    trustActionEl.appendChild(hint);
  }

  const btn = document.createElement("button");
  btn.className = `trust-btn ${verdict.suggestTrust ? "suggest" : "manual"}`;
  btn.textContent = "Mark this site as trusted";
  btn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "ADD_TRUSTED_DOMAIN", hostname }, () => {
      btn.textContent = "Trusted — reload the page to apply";
      btn.disabled = true;
    });
  });
  trustActionEl.appendChild(btn);
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs[0];
  if (!tab || !tab.url || !tab.url.startsWith("http")) {
    badgeEl.textContent = "N/A";
    badgeEl.style.background = "#4b5563";
    reasonsEl.textContent = "This page can't be analyzed.";
    return;
  }
  let hostname;
  try {
    hostname = new URL(tab.url).hostname;
  } catch {
    hostname = "";
  }

  chrome.runtime.sendMessage({ action: "GET_LAST_VERDICT", tabId: tab.id }, (cached) => {
    if (cached && cached.hostname === hostname) {
      renderVerdict(cached, hostname);
      return;
    }
    // No fresh content-script result yet (e.g. popup opened before the page
    // finished analyzing) — fall back to a quick check with no page text,
    // so the AI step is skipped but the fast checks still apply.
    chrome.runtime.sendMessage(
      { action: "ANALYZE_URL", payload: { url: tab.url, hostname, hasUrgentLanguage: false } },
      (verdict) => {
        if (!verdict) {
          badgeEl.textContent = "Error";
          badgeEl.style.background = "#4b5563";
          return;
        }
        renderVerdict(verdict, hostname);
      }
    );
  });
});

function renderVerdict(verdict, hostname) {
  badgeEl.textContent = labels[verdict.level];
  badgeEl.style.background = colors[verdict.level];
  reasonsEl.textContent = (verdict.reasons || []).join(" • ");
  renderTrustAction(verdict, hostname);
}
