# AussieGuard — Anti-Scam Shield (v1.0.0)

## What it does
- Checks every page's domain against a small built-in list of commonly-spoofed
  brand/government domains and flags close look-alikes ("typosquats").
- Optionally cross-checks against Google Safe Browsing if you add your own
  free API key in the extension's options page.
- Scans visible page text for common scam/urgency phrasing.
- Shows a floating green/yellow/red badge (top-right) and a matching toolbar
  badge with a one-line reason on click / in the popup.
- On pages that look like a shopping checkout, shows a small dismissible
  suggestion pointing to an Australian-made alternative in a few categories.
  This is a passive suggestion only — it never reads, fills, or touches any
  payment or card fields.

## Load it (unpacked, for testing)
1. Open `chrome://extensions`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked" and select this folder
4. Visit any site — the badge should appear top-right within a second or two

## Trusted sites list
There are two layers: a short built-in `KNOWN_DOMAINS` list in `background.js`,
and a user-controlled list you build over time from the popup. When a page
is "Unverified," open the popup and click "Mark this site as trusted" to
add it — this is the only thing that ever adds a domain to the trusted list;
the AI (below) can only *suggest* a click, never apply it itself. Already-
trusted-by-you domains show a "Remove from my trusted list" button instead.
A typosquat check still runs against both lists, so a look-alike of a
domain you trusted is still caught.

## AI review — one-time backend setup (no per-user API key)
The extension itself never contains an Anthropic API key — that would be
readable by anyone who inspects the extension's files. Instead, `worker.js`
is a small Cloudflare Worker that holds the key server-side; the extension
calls it instead of calling Anthropic directly. This is a *third* signal,
used only as a tie-breaker: it only runs when the typosquat check and Safe
Browsing (if configured) are both inconclusive. Once deployed, every user
of this extension build gets AI checks automatically — nobody has to enter
a key.

**Deploy it once (~5 minutes):**
1. `npm install -g wrangler` (Cloudflare's CLI), then `wrangler login`
2. `wrangler secret put ANTHROPIC_API_KEY` — paste your Anthropic key
3. `wrangler secret put EXTENSION_SHARED_SECRET` — make up any random
   string; this is a password between the extension and your Worker so
   strangers can't use your Worker as a free relay onto your Anthropic
   account. It is not your Anthropic key.
4. `wrangler deploy` — this prints a URL like
   `https://aussieguard-ai.<you>.workers.dev`
5. In `background.js`, set `AI_WORKER_URL` to that URL + `/check`, and
   `WORKER_SHARED_SECRET` to the same random string from step 3
6. Reload the extension in `chrome://extensions`

Until you do this, `AI_WORKER_URL` still has its placeholder value and the
extension simply skips the AI step (typosquat + Safe Browsing keep working
as normal) — nothing breaks, it just runs with one fewer signal.

The Worker's rate limiting is a basic per-IP in-memory counter — fine for
personal use or a small group. If you're publishing this widely, swap it
for Cloudflare's built-in Rate Limiting or a KV/Durable-Object-backed
counter (noted in `worker.js`), since in-memory counters reset whenever the
Worker instance recycles and don't protect against distributed abuse.
You're also responsible for the Anthropic usage costs of everyone using
this Worker, since your key funds all of their AI checks — keep that in
mind before distributing the extension widely.

## What it looks at, and what it never touches for card safety
When a page has something that looks like a card-number field, the AI is
also asked specifically whether it looks *safe to enter card details into*
(merchant identifiable, recognizable/legitimate checkout flow, etc.). If it
says "risky," the page is escalated to "scam" and the existing card-field
lock (see below) engages automatically — including inside a cross-origin
payment iframe (Braintree/Stripe/Adyen etc.), since the content script runs
in every frame. If it says "safe," that only shows as an informational note
in the badge tooltip — it does **not** add the domain to the trusted list;
only your own click in the popup does that.

## Optional: Safe Browsing API key
Click the extension icon → "Add Safe Browsing API key" → paste a key from
https://developers.google.com/safe-browsing/v4/get-started. Without a key,
the extension still works using the typosquat + keyword checks alone.

## Known limitations (by design)
- The known-domain and Australian-alternative lists are short starter lists —
  extend `KNOWN_DOMAINS` in `background.js` and `AU_ALTERNATIVES` in
  `content.js` as needed.
- The scam-keyword scan is a simple substring match, not a full on-device
  LLM — that's a much larger addition (WebLLM/WebGPU model, several MB) and
  worth doing as a separate follow-up if you want it.
- There is intentionally no payment interception, wallet integration, or
  checkout-field automation anywhere in this extension.
