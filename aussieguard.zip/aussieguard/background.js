// background.js — service worker
// Computes a trust verdict for a page's hostname and keeps the toolbar badge in sync.

// A short list of frequently-spoofed brand/government domains, weighted toward
// sites Australian users are commonly phished with. Extend this list as needed.
const KNOWN_DOMAINS = [
  "amazon.com", "amazon.com.au", "paypal.com", "apple.com", "microsoft.com",
  "google.com", "netflix.com", "facebook.com", "instagram.com",
  "commbank.com.au", "anz.com.au", "nab.com.au", "westpac.com.au",
  "auspost.com.au", "ato.gov.au", "mygov.gov.au", "servicesaustralia.gov.au",
  "linkedin.com", "dhl.com", "fedex.com", "ebay.com", "ebay.com.au"
];

// --- Levenshtein distance, used to flag near-miss ("typosquat") domains ---
function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }
  return dp[m][n];
}

function normalizeHost(host) {
  return host.toLowerCase().replace(/^www\./, "");
}

// User-approved domains: sites *you* have explicitly clicked "trust" on.
// Kept separate from KNOWN_DOMAINS so it's obvious which trust decisions
// were hardcoded by the extension vs. made by you.
async function getUserTrustedDomains() {
  const { userTrustedDomains } = await chrome.storage.local.get(["userTrustedDomains"]);
  return userTrustedDomains || [];
}

async function addUserTrustedDomain(hostname) {
  const host = normalizeHost(hostname);
  const current = await getUserTrustedDomains();
  if (!current.includes(host)) current.push(host);
  await chrome.storage.local.set({ userTrustedDomains: current });
  return current;
}

async function removeUserTrustedDomain(hostname) {
  const host = normalizeHost(hostname);
  const current = await getUserTrustedDomains();
  const next = current.filter((d) => d !== host);
  await chrome.storage.local.set({ userTrustedDomains: next });
  return next;
}

function checkTyposquat(hostname, knownDomains, userDomains) {
  const host = normalizeHost(hostname);
  if (userDomains.includes(host)) {
    return { isKnownGood: true, source: "user" };
  }
  if (knownDomains.includes(host)) {
    return { isKnownGood: true, source: "builtin" };
  }
  // Compare against both lists so a typosquat of a domain *you* trusted is
  // still caught, not just typosquats of the built-in list.
  const allDomains = [...knownDomains, ...userDomains];
  for (const known of allDomains) {
    // Only compare against domains of similar length so short unrelated
    // domains don't trigger false positives via edit distance alone.
    if (Math.abs(host.length - known.length) > 3) continue;
    const dist = levenshtein(host, known);
    if (dist > 0 && dist <= 2) {
      return { isKnownGood: false, suspectedTarget: known, distance: dist };
    }
  }
  return { isKnownGood: false };
}

// --- Optional Google Safe Browsing lookup (user supplies their own API key) ---
async function checkSafeBrowsing(url) {
  const { safeBrowsingApiKey } = await chrome.storage.local.get(["safeBrowsingApiKey"]);
  if (!safeBrowsingApiKey) return { checked: false };

  try {
    const resp = await fetch(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${safeBrowsingApiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          client: { clientId: "aussieguard-extension", clientVersion: "1.0.0" },
          threatInfo: {
            threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
            platformTypes: ["ANY_PLATFORM"],
            threatEntryTypes: ["URL"],
            threatEntries: [{ url }]
          }
        })
      }
    );
    if (!resp.ok) return { checked: true, error: true };
    const data = await resp.json();
    return { checked: true, flagged: Boolean(data.matches && data.matches.length) };
  } catch (e) {
    return { checked: true, error: true };
  }
}

// --- AI review, via a backend proxy you deploy (see worker.js) ---
// The extension itself never contains an Anthropic API key — it calls your
// deployed Worker, which holds the key server-side. Fill these in after
// deploying worker.js (see its header comment for the 5-minute setup).
const AI_WORKER_URL = "https://YOUR-WORKER-SUBDOMAIN.workers.dev/check";
const WORKER_SHARED_SECRET = "REPLACE_WITH_THE_SAME_RANDOM_STRING_YOU_SET_AS_EXTENSION_SHARED_SECRET";

// Only called when the cheap checks below are inconclusive ("unknown"), to
// keep this fast and low-cost. Never used to *upgrade* a page to "trusted" —
// only to escalate an unknown page to "scam" if the model spots something.
const aiVerdictCache = new Map(); // hostname -> { level, reasons, expiresAt }
const AI_CACHE_TTL_MS = 10 * 60 * 1000;

async function checkWithAI(hostname, url, pageText) {
  const cached = aiVerdictCache.get(hostname);
  if (cached && cached.expiresAt > Date.now()) return cached;

  if (!pageText || AI_WORKER_URL.includes("YOUR-WORKER-SUBDOMAIN")) return null; // not deployed yet

  try {
    const resp = await fetch(AI_WORKER_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-extension-secret": WORKER_SHARED_SECRET
      },
      body: JSON.stringify({ url, pageText: pageText.slice(0, 4000) })
    });
    if (!resp.ok) return null;
    const parsed = await resp.json();
    if (parsed.error) return null;

    let result;
    if (parsed.verdict === "scam") {
      result = { level: "scam", reasons: [`AI review: ${parsed.reason}`], suggestTrust: false };
    } else if (parsed.verdict === "likely-legitimate") {
      result = { level: "unknown", reasons: [], suggestTrust: true, suggestReason: parsed.reason };
    } else {
      result = { level: "unknown", reasons: [], suggestTrust: false };
    }
    result.cardSafety = parsed.cardSafety || "unclear";
    result.cardSafetyReason = parsed.cardReason || "";

    aiVerdictCache.set(hostname, { ...result, expiresAt: Date.now() + AI_CACHE_TTL_MS });
    return result;
  } catch (e) {
    return null; // fail closed to "no AI signal", never throw
  }
}

// Combines all signals into a single verdict: "trusted" | "unknown" | "scam".
// "trusted" is only ever reached via KNOWN_DOMAINS or a domain *you* added —
// the AI signal can escalate to "scam" or suggest a trust click, but can
// never set "trusted" on its own.
async function computeVerdict({ url, hostname, hasUrgentLanguage, pageText, hasCardField }) {
  const reasons = [];
  const userDomains = await getUserTrustedDomains();
  const typo = checkTyposquat(hostname, KNOWN_DOMAINS, userDomains);
  const safeBrowsing = await checkSafeBrowsing(url);

  if (safeBrowsing.flagged) {
    reasons.push("Flagged by Google Safe Browsing");
    return { level: "scam", reasons };
  }

  if (typo.suspectedTarget) {
    reasons.push(`Domain closely resembles ${typo.suspectedTarget} (possible typosquat)`);
    return { level: "scam", reasons };
  }

  if (typo.isKnownGood && !safeBrowsing.error) {
    reasons.push(
      typo.source === "user"
        ? "You've marked this domain as trusted"
        : "Matches a known, verified domain"
    );
    return { level: "trusted", reasons };
  }

  if (hasUrgentLanguage) {
    reasons.push("Page contains urgency/pressure language commonly used in scams");
  }

  // Cheap checks were inconclusive — ask the AI model for a second opinion,
  // if the user has configured a key.
  const aiResult = await checkWithAI(hostname, url, pageText);
  if (aiResult && aiResult.level === "scam") {
    return { level: "scam", reasons: [...reasons, ...aiResult.reasons] };
  }

  // A card field is present and the AI specifically flagged the checkout as
  // unsafe — escalate to "scam" even if nothing else did. This is what
  // triggers the card-field lock.
  if (aiResult && hasCardField && aiResult.cardSafety === "risky") {
    reasons.push(`AI flagged this checkout as unsafe for card details: ${aiResult.cardSafetyReason}`);
    return { level: "scam", reasons };
  }

  reasons.push("No known indicators found — domain not in our trusted list");
  const verdict = { level: "unknown", reasons };
  if (aiResult && aiResult.suggestTrust) {
    verdict.suggestTrust = true;
    verdict.suggestReason = aiResult.suggestReason;
  }
  if (aiResult && hasCardField && aiResult.cardSafety === "safe") {
    verdict.cardSafetyNote = aiResult.cardSafetyReason;
  }
  return verdict;
}

const BADGE_COLORS = {
  trusted: "#10b981",
  unknown: "#f59e0b",
  scam: "#ef4444"
};

function setBadge(tabId, level) {
  const text = level === "trusted" ? "OK" : level === "scam" ? "!!!" : "?";
  chrome.action.setBadgeBackgroundColor({ tabId, color: BADGE_COLORS[level] });
  chrome.action.setBadgeText({ tabId, text });
}

// Caches the last verdict computed for each tab (from the content script's
// full analysis, including AI results) so the popup can show the same
// verdict instead of re-running a blind check with no page text.
const lastVerdictByTab = new Map(); // tabId -> { ...verdict, hostname }
// Caches the payload from each tab's last ANALYZE_URL call, so a card field
// discovered late (e.g. in a slower-loading payment iframe) can trigger a
// fresh, correctly-contexted AI check without needing to re-send page text.
const lastPayloadByTab = new Map(); // tabId -> { url, hostname, pageText, ... }

async function handleLateCardFieldDetection(tabId) {
  const payload = lastPayloadByTab.get(tabId);
  const cachedVerdict = lastVerdictByTab.get(tabId);
  if (!payload || !cachedVerdict) return; // top frame hasn't reported in yet
  if (cachedVerdict.level === "scam" || cachedVerdict.level === "trusted") return;

  const aiResult = await checkWithAI(payload.hostname, payload.url, payload.pageText);
  if (aiResult && aiResult.cardSafety === "risky") {
    const newVerdict = {
      level: "scam",
      reasons: [
        ...(cachedVerdict.reasons || []),
        `AI flagged this checkout as unsafe for card details: ${aiResult.cardSafetyReason}`
      ]
    };
    lastVerdictByTab.set(tabId, { ...newVerdict, hostname: payload.hostname });
    setBadge(tabId, "scam");
    chrome.tabs.sendMessage(tabId, { action: "VERDICT_UPDATE", verdict: newVerdict });
    chrome.tabs.sendMessage(tabId, { action: "ENABLE_CARD_LOCK" });
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "ANALYZE_URL") {
    const tabId = sender.tab && sender.tab.id;
    if (tabId !== undefined) lastPayloadByTab.set(tabId, message.payload);
    computeVerdict(message.payload).then((verdict) => {
      if (tabId !== undefined) {
        setBadge(tabId, verdict.level);
        lastVerdictByTab.set(tabId, { ...verdict, hostname: message.payload.hostname });
      }
      sendResponse(verdict);
    });
    return true; // keep the message channel open for the async response
  }

  if (message.action === "GET_LAST_VERDICT") {
    sendResponse(lastVerdictByTab.get(message.tabId) || null);
    return false;
  }

  if (message.action === "CARD_FIELD_PRESENT") {
    const tabId = sender.tab && sender.tab.id;
    if (tabId !== undefined) handleLateCardFieldDetection(tabId);
    return false;
  }

  if (message.action === "REQUEST_CARD_LOCK_BROADCAST") {
    const tabId = sender.tab && sender.tab.id;
    if (tabId !== undefined) {
      // No frameId given, so this reaches every frame in the tab, including
      // any cross-origin payment iframe (Braintree/Stripe/Adyen etc.).
      chrome.tabs.sendMessage(tabId, { action: "ENABLE_CARD_LOCK" });
    }
    return false;
  }

  if (message.action === "ADD_TRUSTED_DOMAIN") {
    addUserTrustedDomain(message.hostname).then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.action === "REMOVE_TRUSTED_DOMAIN") {
    removeUserTrustedDomain(message.hostname).then(() => sendResponse({ success: true }));
    return true;
  }
});

// Clear the badge and cached verdict/payload on navigation so stale results
// don't linger between pages.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    chrome.action.setBadgeText({ tabId, text: "" });
    lastVerdictByTab.delete(tabId);
    lastPayloadByTab.delete(tabId);
  }
});
